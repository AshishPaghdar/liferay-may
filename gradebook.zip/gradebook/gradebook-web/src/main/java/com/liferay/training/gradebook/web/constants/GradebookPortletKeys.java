package com.liferay.training.gradebook.web.constants;

/**
 * @author hgrahul
 */
public class GradebookPortletKeys {
	// This Represent As Portlet Identification or Portlet Name (Internal Name)
	public static final String PORTLET_NAME = "com_liferay_training_gradebook_web_portlet_GradebookPortlet";
}